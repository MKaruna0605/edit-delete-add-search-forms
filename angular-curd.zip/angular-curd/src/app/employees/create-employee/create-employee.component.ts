import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Department } from "src/app/models/department.model";
import { Employee } from "src/app/models/employee.model";
import { EmployeeService } from "src/app/employees/employee.service";
import { Router } from '@angular/router';
import { ViewChild } from '@angular/core';
import { ActivatedRoute } from "@angular/router";

@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html', 
  styleUrls: ['./create-employee.component.css']
})
export class CreateEmployeeComponent implements OnInit {

  @ViewChild('employeeForm') public createEmployeeForm: NgForm;
  previewPhoto=false;
panelTitle: string;

  employee: Employee; 
 departments :  Department[] =[
   {id:1,name:'Help Desk'},
    {id:2,name:'HR'},
     {id:3,name:'IT'},
      {id:4,name:'Payroll'}
 ];
  constructor(private _employeeService: EmployeeService,
  private _router: Router,
  private _route: ActivatedRoute) { }


togglePhotoPreview(){
  this.previewPhoto=!this.previewPhoto;
}

  ngOnInit() {
    this._route.paramMap.subscribe(parameterMap => {
const id = +parameterMap.get('id');
this.getEmployee(id);
    });
  }



private getEmployee(id: number){
if(id === 0){
  this.employee = {
    id:null,
    name: null,
    gender: null,
    email: '',
    phoneNumber: null,
    contactPreference: null,
    dateOfBirth: null,
    department: 'select',
    isActive: null,
    photoPath: null,
      };
      this.panelTitle = 'Create Employee';
      this.createEmployeeForm.reset();
}else{
   this.panelTitle = 'Edit Employee';
  this.employee = Object.assign({}, this._employeeService.getEmployee(id));
}

}


saveEmployee(): void{
 const newEmployee: Employee  = Object.assign({}, this.employee);
  
 this._employeeService.save(newEmployee);
this.createEmployeeForm.reset();
this._router.navigate(['list']);
}
 
}
